# Train an ADAPT-GPT model
# Based on https://github.com/karpathy/nanoGPT/blob/master/config/train_shakespeare_char.py

out_dir = 'out-save_dir_3k'
eval_interval = 100 # keep frequent because we'll overfit
eval_iters = 25
log_interval = 20 # don't print too too often
eval_ar_every = 500 # how often we do approx ratio evaluation (calling ADAPT-QAOA cudaq)

# we expect to overfit on this small dataset, so only save when val improves
always_save_checkpoint = False

dataset = 'save_dir_3k'
gradient_accumulation_steps = 1
batch_size = 32
block_size = 256 # context of up to 256 previous characters

# baby GPT model :)
n_layer = 6
n_head = 6
n_embd = 384
dropout = 0.2

learning_rate = 1e-4 # with baby networks can afford to go a bit higher
n_epochs = 50
max_iters = 3700
lr_decay_iters = 3700 # make equal to max_iters usually
min_lr = 1e-5 # learning_rate / 10 usually
beta2 = 0.95 # make a bit bigger because number of tokens per iter is small

warmup_iters = 100 # not super necessary potentially

graph_emb_dim = 500 # default for FEATHER graph
use_graph_emb = True
pool_type = 'qaoa_mixer'
n_nodes = 8
token_seq_round = 'token_seq_round_d2'  # rounding digits for token sequence
n_samples = 5

# on macbook also add
# device = 'cpu'  # run on cpu only
# compile = False # do not torch compile the model
